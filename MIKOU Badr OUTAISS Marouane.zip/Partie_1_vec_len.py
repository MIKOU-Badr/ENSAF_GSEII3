# this module will be imported in the into your flowgraph
import numpy as np
from math import ceil,log

def get_len():
	data = np.fromfile("/home/mikou-badr/TP_TSP/TP2/enregistrement1.wav",dtype=np.float32)
	return len(data)
	
def get_nfft():
	next = pow(2, ceil(log(get_len())/log(2)));
	return next
