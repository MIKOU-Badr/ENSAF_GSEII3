import numpy as np
from math import log10
import matplotlib.pyplot as plt

file = np.fromfile("/home/mikou-badr/TP_TSP/TP2/analyse_spectrale.txt", dtype=np.float32)
t = np.linspace(0, 1, int(len(file)/2))
# Tracé du signal
arr = 20*np.log10(file[:int(len(file)/2)])

plt.plot(t, arr)
plt.grid()
plt.ylabel(r"$Amplitude$ (dB)")
plt.xlabel(r"Fréquence")
plt.title(r"Spectre du signal eregistré")
plt.show()

